package com.isril.lockbyisril;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.view.accessibility.AccessibilityEvent;

public class LockAccessibilityService extends AccessibilityService {
    private String lastPackage;
    private final BroadcastReceiver screenReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                SessionManager.clearAll();
            }
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(screenReceiver, filter);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (pkg.isEmpty()) return;

        if (lastPackage != null && !lastPackage.equals(pkg)
                && !lastPackage.equals(getPackageName())
                && Prefs.isAppLocked(this, lastPackage)) {
            SessionManager.markExited(lastPackage);
        }
        lastPackage = pkg;

        if (pkg.equals(getPackageName())) return;
        if (!Prefs.isProtectionActive(this)) return;
        if (!Prefs.isAppLocked(this, pkg)) return;
        if (LockActivity.visible) return;
        if (!SessionManager.shouldLock(this, pkg)) return;

        Intent lock = new Intent(this, LockActivity.class);
        lock.putExtra(LockActivity.EXTRA_TARGET, pkg);
        lock.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP
                | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(lock);
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        try { unregisterReceiver(screenReceiver); } catch (Exception ignored) {}
        super.onDestroy();
    }
}
