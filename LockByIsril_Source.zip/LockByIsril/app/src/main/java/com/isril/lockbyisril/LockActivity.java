package com.isril.lockbyisril;

import android.app.Activity;
import android.app.KeyguardManager;
import android.content.Intent;
import android.graphics.Color;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;
import java.util.concurrent.Executor;

public class LockActivity extends Activity {
    public static final String EXTRA_TARGET = "target_package";
    public static final String EXTRA_MODE = "mode";
    public static final String MODE_SETTINGS = "settings";
    public static volatile boolean visible = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private String targetPackage;
    private boolean settingsMode;
    private TextView message;
    private PatternView patternView;
    private LinearLayout pinArea;
    private TextView pinDots;
    private final StringBuilder pin = new StringBuilder();
    private CancellationSignal biometricCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        visible = true;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        targetPackage = getIntent().getStringExtra(EXTRA_TARGET);
        settingsMode = MODE_SETTINGS.equals(getIntent().getStringExtra(EXTRA_MODE));
        buildUi();
        updateLockoutUi();
        if (Prefs.isBiometricEnabled(this)) handler.postDelayed(this::authenticateFingerprint, 350);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        targetPackage = intent.getStringExtra(EXTRA_TARGET);
        settingsMode = MODE_SETTINGS.equals(intent.getStringExtra(EXTRA_MODE));
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ImageView bg = new ImageView(this);
        bg.setBackgroundColor(Color.BLACK);
        bg.setScaleType(ImageView.ScaleType.FIT_CENTER);
        String custom = Prefs.getBackgroundUri(this);
        try {
            if (custom != null) bg.setImageURI(Uri.parse(custom));
            else bg.setImageResource(R.drawable.lock_background);
        } catch (Exception e) {
            bg.setImageResource(R.drawable.lock_background);
        }
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        View dim = new View(this);
        int level = Prefs.getBackgroundDim(this);
        int alpha = level == 0 ? 0 : level == 2 ? 115 : 65;
        dim.setBackgroundColor(Color.argb(alpha, 0, 0, 0));
        root.addView(dim, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setPadding(dp(22), dp(38), dp(22), dp(28));
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        TextView title = text("Lock by Isril", 22, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        content.addView(title, new LinearLayout.LayoutParams(-1, -2));

        message = text(Prefs.METHOD_PIN.equals(Prefs.getMethod(this)) ? "Enter PIN" : "Draw pattern", 17, Color.LTGRAY);
        message.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
        mp.topMargin = dp(12);
        content.addView(message, mp);

        View spacer = new View(this);
        content.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1f));

        if (Prefs.METHOD_PIN.equals(Prefs.getMethod(this))) buildPin(content);
        else buildPattern(content);

        Button bio = new Button(this);
        bio.setText("Use fingerprint");
        bio.setAllCaps(false);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(50));
        bp.topMargin = dp(12);
        content.addView(bio, bp);
        bio.setVisibility(Prefs.isBiometricEnabled(this) ? View.VISIBLE : View.GONE);
        bio.setOnClickListener(v -> authenticateFingerprint());

        setContentView(root);
    }

    private void buildPattern(LinearLayout content) {
        patternView = new PatternView(this);
        patternView.setShowLines(Prefs.showPatternLines(this));
        patternView.setShowTouches(Prefs.showPatternTouches(this));
        patternView.setHaptic(Prefs.patternHaptic(this));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(315), dp(315));
        content.addView(patternView, pp);
        patternView.setListener(this::onPattern);
    }

    private void onPattern(List<Integer> pattern) {
        if (isLockedOut()) return;
        String value = PatternView.serialize(pattern);
        if (CredentialStore.verify(this, value)) success();
        else failure("Wrong pattern");
    }

    private void buildPin(LinearLayout content) {
        pinArea = new LinearLayout(this);
        pinArea.setOrientation(LinearLayout.VERTICAL);
        pinArea.setGravity(Gravity.CENTER_HORIZONTAL);

        pinDots = text("", 28, Color.WHITE);
        pinDots.setGravity(Gravity.CENTER);
        pinArea.addView(pinDots, new LinearLayout.LayoutParams(-1, dp(52)));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        grid.setRowCount(4);
        String[] labels = {"1","2","3","4","5","6","7","8","9","⌫","0","OK"};
        for (String label : labels) {
            Button b = new Button(this);
            b.setText(label);
            b.setTextSize(18);
            b.setAllCaps(false);
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = dp(88);
            gp.height = dp(62);
            gp.setMargins(dp(3), dp(3), dp(3), dp(3));
            grid.addView(b, gp);
            if ("⌫".equals(label)) b.setOnClickListener(v -> backspacePin());
            else if ("OK".equals(label)) b.setOnClickListener(v -> submitPin());
            else b.setOnClickListener(v -> addPin(label));
        }
        pinArea.addView(grid);
        content.addView(pinArea, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addPin(String digit) {
        if (isLockedOut() || pin.length() >= 8) return;
        pin.append(digit);
        updatePinDots();
    }

    private void backspacePin() {
        if (pin.length() > 0) pin.deleteCharAt(pin.length() - 1);
        updatePinDots();
    }

    private void updatePinDots() {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < pin.length(); i++) s.append("• ");
        pinDots.setText(s.toString().trim());
    }

    private void submitPin() {
        if (isLockedOut()) return;
        if (CredentialStore.verify(this, pin.toString())) success();
        else {
            pin.setLength(0);
            updatePinDots();
            failure("Wrong PIN");
        }
    }

    private void success() {
        Prefs.setFailedAttempts(this, 0);
        Prefs.setLockoutUntil(this, 0L);
        if (settingsMode) {
            setResult(RESULT_OK);
        } else {
            SessionManager.markUnlocked(targetPackage);
        }
        finish();
    }

    private void failure(String text) {
        int fails = Prefs.getFailedAttempts(this) + 1;
        if (fails >= 5) {
            Prefs.setFailedAttempts(this, 0);
            Prefs.setLockoutUntil(this, System.currentTimeMillis() + 30_000L);
            if (patternView != null) patternView.clearPattern();
            updateLockoutUi();
        } else {
            Prefs.setFailedAttempts(this, fails);
            message.setText(text + ". " + (5 - fails) + " attempts left");
            if (patternView != null) patternView.showError();
        }
    }

    private boolean isLockedOut() {
        return System.currentTimeMillis() < Prefs.getLockoutUntil(this);
    }

    private void updateLockoutUi() {
        long remaining = Prefs.getLockoutUntil(this) - System.currentTimeMillis();
        boolean locked = remaining > 0;
        if (patternView != null) patternView.setEnabled(!locked);
        if (pinArea != null) pinArea.setEnabled(!locked);
        if (locked) {
            long seconds = Math.max(1, (remaining + 999) / 1000);
            message.setText("Try again in " + seconds + " seconds");
            handler.postDelayed(this::updateLockoutUi, 1000);
        } else if (message != null && message.getText().toString().startsWith("Try again")) {
            message.setText(Prefs.METHOD_PIN.equals(Prefs.getMethod(this)) ? "Enter PIN" : "Draw pattern");
        }
    }

    private void authenticateFingerprint() {
        if (!Prefs.isBiometricEnabled(this) || android.os.Build.VERSION.SDK_INT < 28) return;
        try {
            KeyguardManager km = getSystemService(KeyguardManager.class);
            if (km == null || !km.isDeviceSecure()) {
                message.setText("Set a device screen lock before using fingerprint");
                return;
            }
            if (biometricCancel != null) biometricCancel.cancel();
            biometricCancel = new CancellationSignal();
            Executor executor = getMainExecutor();
            BiometricPrompt prompt = new BiometricPrompt.Builder(this)
                    .setTitle("Unlock Lock by Isril")
                    .setSubtitle("Use your fingerprint")
                    .setNegativeButton("Use app lock", executor, (dialog, which) -> {})
                    .build();
            prompt.authenticate(biometricCancel, executor, new BiometricPrompt.AuthenticationCallback() {
                @Override
                public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                    super.onAuthenticationSucceeded(result);
                    success();
                }

                @Override
                public void onAuthenticationError(int errorCode, CharSequence errString) {
                    super.onAuthenticationError(errorCode, errString);
                }

                @Override
                public void onAuthenticationFailed() {
                    super.onAuthenticationFailed();
                    message.setText("Fingerprint not recognized");
                }
            });
        } catch (Exception e) {
            message.setText("Fingerprint is not available");
        }
    }

    @Override
    public void onBackPressed() {
        if (settingsMode) {
            setResult(RESULT_CANCELED);
            finish();
            return;
        }
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(home);
        finish();
    }

    @Override
    protected void onDestroy() {
        if (biometricCancel != null) biometricCancel.cancel();
        visible = false;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
