package com.isril.lockbyisril;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public final class Prefs {
    private static final String NAME = "lock_prefs";
    private static final String K_SETUP = "setup_complete";
    private static final String K_METHOD = "lock_method";
    private static final String K_PROTECTION = "protection_enabled";
    private static final String K_BIOMETRIC = "biometric_enabled";
    private static final String K_LOCKED = "locked_apps";
    private static final String K_DELAY = "auto_lock_delay_ms";
    private static final String K_TEMP_OFF = "temp_off_until";
    private static final String K_BG_URI = "background_uri";
    private static final String K_DIM = "background_dim";
    private static final String K_LINES = "show_pattern_lines";
    private static final String K_TOUCHES = "show_pattern_touches";
    private static final String K_HAPTIC = "pattern_haptic";
    private static final String K_FAILS = "failed_attempts";
    private static final String K_LOCKOUT = "lockout_until";

    public static final String METHOD_PATTERN = "pattern";
    public static final String METHOD_PIN = "pin";

    private Prefs() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static boolean isSetupComplete(Context c) { return p(c).getBoolean(K_SETUP, false); }
    public static void setSetupComplete(Context c, boolean v) { p(c).edit().putBoolean(K_SETUP, v).apply(); }

    public static String getMethod(Context c) { return p(c).getString(K_METHOD, METHOD_PATTERN); }
    public static void setMethod(Context c, String v) { p(c).edit().putString(K_METHOD, v).apply(); }

    public static boolean isProtectionEnabled(Context c) { return p(c).getBoolean(K_PROTECTION, true); }
    public static void setProtectionEnabled(Context c, boolean v) {
        p(c).edit().putBoolean(K_PROTECTION, v).apply();
        if (v) p(c).edit().putLong(K_TEMP_OFF, 0L).apply();
    }

    public static boolean isProtectionActive(Context c) {
        if (!isProtectionEnabled(c)) return false;
        long until = p(c).getLong(K_TEMP_OFF, 0L);
        return until <= 0L || System.currentTimeMillis() >= until;
    }

    public static long getTemporaryOffUntil(Context c) { return p(c).getLong(K_TEMP_OFF, 0L); }
    public static void setTemporaryOffUntil(Context c, long v) { p(c).edit().putLong(K_TEMP_OFF, v).apply(); }

    public static boolean isBiometricEnabled(Context c) { return p(c).getBoolean(K_BIOMETRIC, true); }
    public static void setBiometricEnabled(Context c, boolean v) { p(c).edit().putBoolean(K_BIOMETRIC, v).apply(); }

    public static Set<String> getLockedApps(Context c) {
        Set<String> set = p(c).getStringSet(K_LOCKED, Collections.emptySet());
        return new HashSet<>(set == null ? Collections.emptySet() : set);
    }

    public static void setLockedApps(Context c, Set<String> set) {
        p(c).edit().putStringSet(K_LOCKED, new HashSet<>(set)).apply();
    }

    public static boolean isAppLocked(Context c, String pkg) { return getLockedApps(c).contains(pkg); }

    public static long getAutoLockDelay(Context c) { return p(c).getLong(K_DELAY, 60_000L); }
    public static void setAutoLockDelay(Context c, long ms) { p(c).edit().putLong(K_DELAY, ms).apply(); }

    public static String getBackgroundUri(Context c) { return p(c).getString(K_BG_URI, null); }
    public static void setBackgroundUri(Context c, String uri) {
        SharedPreferences.Editor e = p(c).edit();
        if (uri == null) e.remove(K_BG_URI); else e.putString(K_BG_URI, uri);
        e.apply();
    }

    public static int getBackgroundDim(Context c) { return p(c).getInt(K_DIM, 1); }
    public static void setBackgroundDim(Context c, int level) { p(c).edit().putInt(K_DIM, level).apply(); }

    public static boolean showPatternLines(Context c) { return p(c).getBoolean(K_LINES, false); }
    public static void setShowPatternLines(Context c, boolean v) { p(c).edit().putBoolean(K_LINES, v).apply(); }

    public static boolean showPatternTouches(Context c) { return p(c).getBoolean(K_TOUCHES, true); }
    public static void setShowPatternTouches(Context c, boolean v) { p(c).edit().putBoolean(K_TOUCHES, v).apply(); }

    public static boolean patternHaptic(Context c) { return p(c).getBoolean(K_HAPTIC, true); }
    public static void setPatternHaptic(Context c, boolean v) { p(c).edit().putBoolean(K_HAPTIC, v).apply(); }

    public static int getFailedAttempts(Context c) { return p(c).getInt(K_FAILS, 0); }
    public static void setFailedAttempts(Context c, int n) { p(c).edit().putInt(K_FAILS, n).apply(); }

    public static long getLockoutUntil(Context c) { return p(c).getLong(K_LOCKOUT, 0L); }
    public static void setLockoutUntil(Context c, long t) { p(c).edit().putLong(K_LOCKOUT, t).apply(); }
}
