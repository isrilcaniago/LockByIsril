package com.isril.lockbyisril;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class SetupCredentialActivity extends Activity {
    public static final String EXTRA_METHOD = "method";
    private String method;
    private String first;
    private TextView title;
    private PatternView patternView;
    private EditText pinInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        method = getIntent().getStringExtra(EXTRA_METHOD);
        if (!Prefs.METHOD_PIN.equals(method)) method = Prefs.METHOD_PATTERN;
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(48), dp(24), dp(24));
        root.setBackgroundColor(Color.BLACK);

        TextView app = text("Lock by Isril", 26, Color.WHITE);
        app.setGravity(Gravity.CENTER);
        root.addView(app, new LinearLayout.LayoutParams(-1, -2));

        title = text(Prefs.METHOD_PATTERN.equals(method) ? "Draw a new pattern" : "Enter a new PIN", 18, Color.LTGRAY);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(28);
        root.addView(title, tp);

        if (Prefs.METHOD_PATTERN.equals(method)) buildPattern(root);
        else buildPin(root);

        setContentView(root);
    }

    private void buildPattern(LinearLayout root) {
        patternView = new PatternView(this);
        patternView.setShowLines(true);
        patternView.setShowTouches(true);
        patternView.setHaptic(true);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(320), dp(320));
        pp.topMargin = dp(32);
        root.addView(patternView, pp);
        patternView.setListener(this::onPattern);
    }

    private void onPattern(List<Integer> pattern) {
        if (pattern.size() < 4) {
            title.setText("Use at least 4 dots");
            patternView.showError();
            return;
        }
        String value = PatternView.serialize(pattern);
        if (first == null) {
            first = value;
            title.setText("Draw the same pattern again");
            patternView.clearPattern();
            return;
        }
        if (!first.equals(value)) {
            first = null;
            title.setText("Patterns did not match. Try again");
            patternView.showError();
            return;
        }
        save(value);
    }

    private void buildPin(LinearLayout root) {
        pinInput = new EditText(this);
        pinInput.setTextColor(Color.WHITE);
        pinInput.setHintTextColor(Color.GRAY);
        pinInput.setHint("4 to 8 digits");
        pinInput.setGravity(Gravity.CENTER);
        pinInput.setTextSize(24);
        pinInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(64));
        ep.topMargin = dp(36);
        root.addView(pinInput, ep);

        Button next = button("Continue");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.topMargin = dp(24);
        root.addView(next, bp);
        next.setOnClickListener(v -> onPin());
    }

    private void onPin() {
        String value = pinInput.getText().toString();
        if (value.length() < 4 || value.length() > 8) {
            title.setText("PIN must be 4 to 8 digits");
            return;
        }
        if (first == null) {
            first = value;
            pinInput.setText("");
            title.setText("Enter the same PIN again");
            return;
        }
        if (!first.equals(value)) {
            first = null;
            pinInput.setText("");
            title.setText("PINs did not match. Try again");
            return;
        }
        save(value);
    }

    private void save(String value) {
        if (!CredentialStore.save(this, value)) {
            Toast.makeText(this, "Could not save the lock credential", Toast.LENGTH_LONG).show();
            return;
        }
        Prefs.setMethod(this, method);
        Prefs.setSetupComplete(this, true);
        Prefs.setFailedAttempts(this, 0);
        Prefs.setLockoutUntil(this, 0L);
        setResult(RESULT_OK);
        finish();
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        return b;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
