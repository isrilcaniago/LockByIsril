package com.isril.lockbyisril;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class PatternView extends View {
    public interface Listener {
        void onPatternComplete(List<Integer> pattern);
    }

    private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint activePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Integer> selected = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Listener listener;
    private boolean showLines = false;
    private boolean showTouches = true;
    private boolean haptic = true;
    private boolean error = false;
    private float currentX;
    private float currentY;
    private boolean tracking;

    public PatternView(Context context) { super(context); init(); }
    public PatternView(Context context, AttributeSet attrs) { super(context, attrs); init(); }

    private void init() {
        setBackgroundColor(Color.TRANSPARENT);
        dotPaint.setColor(Color.argb(145, 225, 235, 240));
        activePaint.setColor(Color.WHITE);
        linePaint.setColor(Color.argb(205, 235, 245, 250));
        linePaint.setStrokeWidth(dp(5));
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setListener(Listener listener) { this.listener = listener; }
    public void setShowLines(boolean showLines) { this.showLines = showLines; invalidate(); }
    public void setShowTouches(boolean showTouches) { this.showTouches = showTouches; invalidate(); }
    public void setHaptic(boolean haptic) { this.haptic = haptic; }

    public void clearPattern() {
        selected.clear();
        tracking = false;
        error = false;
        invalidate();
    }

    public void showError() {
        error = true;
        invalidate();
        handler.postDelayed(this::clearPattern, 500);
    }

    public static String serialize(List<Integer> pattern) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < pattern.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append(pattern.get(i));
        }
        return sb.toString();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float[] xs = centersX();
        float[] ys = centersY();

        if (showLines && selected.size() > 0) {
            linePaint.setColor(error ? Color.argb(220, 255, 95, 95) : Color.argb(205, 235, 245, 250));
            for (int i = 1; i < selected.size(); i++) {
                int a = selected.get(i - 1);
                int b = selected.get(i);
                canvas.drawLine(xs[a % 3], ys[a / 3], xs[b % 3], ys[b / 3], linePaint);
            }
            if (tracking) {
                int a = selected.get(selected.size() - 1);
                canvas.drawLine(xs[a % 3], ys[a / 3], currentX, currentY, linePaint);
            }
        }

        float baseRadius = dp(6);
        float activeRadius = dp(10);
        for (int i = 0; i < 9; i++) {
            boolean isSelected = selected.contains(i);
            Paint p = dotPaint;
            float r = baseRadius;
            if (isSelected && showTouches) {
                p = activePaint;
                if (error) p.setColor(Color.rgb(255, 95, 95));
                else p.setColor(Color.WHITE);
                r = activeRadius;
            }
            canvas.drawCircle(xs[i % 3], ys[i / 3], r, p);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) return true;
        currentX = event.getX();
        currentY = event.getY();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                selected.clear();
                error = false;
                tracking = true;
                addHit(event.getX(), event.getY());
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                addHit(event.getX(), event.getY());
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                tracking = false;
                invalidate();
                if (event.getActionMasked() == MotionEvent.ACTION_UP && listener != null && !selected.isEmpty()) {
                    listener.onPatternComplete(new ArrayList<>(selected));
                }
                return true;
            default:
                return true;
        }
    }

    private void addHit(float x, float y) {
        int hit = findHit(x, y);
        if (hit < 0 || selected.contains(hit)) return;
        if (!selected.isEmpty()) {
            int mid = midpoint(selected.get(selected.size() - 1), hit);
            if (mid >= 0 && !selected.contains(mid)) addNode(mid);
        }
        addNode(hit);
    }

    private void addNode(int node) {
        selected.add(node);
        if (haptic) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private int midpoint(int a, int b) {
        int ar = a / 3, ac = a % 3;
        int br = b / 3, bc = b % 3;
        if ((Math.abs(ar - br) == 2 || Math.abs(ac - bc) == 2)
                && ((ar + br) % 2 == 0) && ((ac + bc) % 2 == 0)) {
            int mr = (ar + br) / 2;
            int mc = (ac + bc) / 2;
            int mid = mr * 3 + mc;
            if (mid != a && mid != b) return mid;
        }
        return -1;
    }

    private int findHit(float x, float y) {
        float[] xs = centersX();
        float[] ys = centersY();
        float radius = Math.max(dp(34), Math.min(getWidth(), getHeight()) / 9f);
        float r2 = radius * radius;
        for (int i = 0; i < 9; i++) {
            float dx = x - xs[i % 3];
            float dy = y - ys[i / 3];
            if (dx * dx + dy * dy <= r2) return i;
        }
        return -1;
    }

    private float[] centersX() {
        float w = getWidth();
        float pad = w * 0.18f;
        float gap = (w - 2 * pad) / 2f;
        return new float[]{pad, pad + gap, pad + 2 * gap};
    }

    private float[] centersY() {
        float h = getHeight();
        float pad = h * 0.18f;
        float gap = (h - 2 * pad) / 2f;
        return new float[]{pad, pad + gap, pad + 2 * gap};
    }

    private float dp(float v) { return v * getResources().getDisplayMetrics().density; }
}
