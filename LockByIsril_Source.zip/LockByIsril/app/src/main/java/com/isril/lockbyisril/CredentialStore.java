package com.isril.lockbyisril;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.MessageDigest;

import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;

public final class CredentialStore {
    private static final String PREF = "credential_store";
    private static final String KEY_HASH = "credential_hmac";
    private static final String ALIAS = "lock_by_isril_hmac_key";

    private CredentialStore() {}

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                .setDigests(KeyProperties.DIGEST_SHA256)
                .build();
        kg.init(spec);
        return kg.generateKey();
    }

    private static byte[] hmac(String value) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(getOrCreateKey());
        return mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
    }

    public static boolean save(Context c, String credential) {
        try {
            String encoded = Base64.encodeToString(hmac(credential), Base64.NO_WRAP);
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_HASH, encoded).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean verify(Context c, String credential) {
        try {
            String stored = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_HASH, null);
            if (stored == null) return false;
            byte[] expected = Base64.decode(stored, Base64.NO_WRAP);
            byte[] actual = hmac(credential);
            return MessageDigest.isEqual(expected, actual);
        } catch (Exception e) {
            return false;
        }
    }
}
