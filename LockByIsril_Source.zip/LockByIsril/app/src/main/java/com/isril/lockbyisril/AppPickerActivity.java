package com.isril.lockbyisril;

import android.app.Activity;
import android.content.pm.LauncherActivityInfo;
import android.content.pm.LauncherApps;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Process;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class AppPickerActivity extends Activity {
    private final List<AppEntry> apps = new ArrayList<>();
    private Set<String> selected;
    private LinearLayout list;

    static class AppEntry {
        final String pkg;
        final String label;
        final LauncherActivityInfo info;
        AppEntry(String pkg, String label, LauncherActivityInfo info) {
            this.pkg = pkg;
            this.label = label;
            this.info = info;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(18, 18, 18));
        getWindow().setNavigationBarColor(Color.BLACK);
        selected = new HashSet<>(Prefs.getLockedApps(this));
        loadApps();
        buildUi();
    }

    private void loadApps() {
        LauncherApps launcherApps = getSystemService(LauncherApps.class);
        if (launcherApps == null) return;
        List<LauncherActivityInfo> infos = launcherApps.getActivityList(null, Process.myUserHandle());
        Map<String, AppEntry> unique = new HashMap<>();
        for (LauncherActivityInfo info : infos) {
            String pkg = info.getApplicationInfo().packageName;
            if (pkg.equals(getPackageName())) continue;
            String label = String.valueOf(info.getLabel());
            if (!unique.containsKey(pkg)) unique.put(pkg, new AppEntry(pkg, label, info));
        }
        apps.addAll(unique.values());
        apps.sort(Comparator.comparing(a -> a.label.toLowerCase(Locale.getDefault())));
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18, 18, 18));
        root.setPadding(dp(16), dp(18), dp(16), dp(12));

        TextView title = new TextView(this);
        title.setText("Locked apps");
        title.setTextSize(25);
        title.setTextColor(Color.WHITE);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        EditText search = new EditText(this);
        search.setHint("Search apps");
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.GRAY);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(56));
        sp.topMargin = dp(12);
        root.addView(search, sp);

        ScrollView scroll = new ScrollView(this);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { render(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });

        render("");
        setContentView(root);
    }

    private void render(String query) {
        list.removeAllViews();
        String q = query.toLowerCase(Locale.getDefault()).trim();
        for (AppEntry app : apps) {
            if (!q.isEmpty() && !app.label.toLowerCase(Locale.getDefault()).contains(q)
                    && !app.pkg.toLowerCase(Locale.getDefault()).contains(q)) continue;
            list.addView(row(app));
        }
    }

    private View row(AppEntry app) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(8), dp(4), dp(8));

        ImageView icon = new ImageView(this);
        try { icon.setImageDrawable(app.info.getBadgedIcon(0)); } catch (Exception ignored) {}
        row.addView(icon, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setPadding(dp(12), 0, dp(8), 0);
        TextView name = new TextView(this);
        name.setText(app.label);
        name.setTextSize(17);
        name.setTextColor(Color.WHITE);
        labels.addView(name);
        TextView pkg = new TextView(this);
        pkg.setText(app.pkg);
        pkg.setTextSize(11);
        pkg.setTextColor(Color.GRAY);
        labels.addView(pkg);
        row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1f));

        Switch sw = new Switch(this);
        sw.setChecked(selected.contains(app.pkg));
        sw.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) selected.add(app.pkg); else selected.remove(app.pkg);
            Prefs.setLockedApps(this, selected);
            SessionManager.clearAll();
        });
        row.addView(sw, new LinearLayout.LayoutParams(-2, -2));
        return row;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
