package com.isril.lockbyisril;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQ_FIRST_SETUP = 10;
    private static final int REQ_UNLOCK_SETTINGS = 11;
    private static final int REQ_CHANGE_CREDENTIAL = 12;
    private static final int REQ_BACKGROUND = 13;

    private boolean verified;
    private TextView statusText;
    private TextView accessText;
    private Switch protectionSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(18, 18, 18));
        getWindow().setNavigationBarColor(Color.BLACK);

        if (!Prefs.isSetupComplete(this)) {
            Intent i = new Intent(this, SetupCredentialActivity.class);
            i.putExtra(SetupCredentialActivity.EXTRA_METHOD, Prefs.METHOD_PATTERN);
            startActivityForResult(i, REQ_FIRST_SETUP);
        } else {
            requestSettingsUnlock();
        }
    }

    private void requestSettingsUnlock() {
        Intent i = new Intent(this, LockActivity.class);
        i.putExtra(LockActivity.EXTRA_MODE, LockActivity.MODE_SETTINGS);
        i.putExtra(LockActivity.EXTRA_TARGET, getPackageName());
        startActivityForResult(i, REQ_UNLOCK_SETTINGS);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FIRST_SETUP) {
            if (resultCode != RESULT_OK) {
                finish();
                return;
            }
            verified = true;
            buildMainUi();
            showFirstRunHelp();
        } else if (requestCode == REQ_UNLOCK_SETTINGS) {
            if (resultCode != RESULT_OK) {
                finish();
                return;
            }
            verified = true;
            buildMainUi();
        } else if (requestCode == REQ_CHANGE_CREDENTIAL) {
            if (resultCode == RESULT_OK) Toast.makeText(this, "Lock method updated", Toast.LENGTH_SHORT).show();
            refreshStatus();
        } else if (requestCode == REQ_BACKGROUND && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            Prefs.setBackgroundUri(this, uri.toString());
            Toast.makeText(this, "Background updated", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (verified) refreshStatus();
    }

    private void buildMainUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(28));
        root.setBackgroundColor(Color.rgb(18, 18, 18));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView title = text("Lock by Isril", 28, Color.WHITE);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        statusText = text("", 15, Color.LTGRAY);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.topMargin = dp(6);
        root.addView(statusText, stp);

        protectionSwitch = new Switch(this);
        protectionSwitch.setText("Protection");
        protectionSwitch.setTextColor(Color.WHITE);
        protectionSwitch.setTextSize(19);
        LinearLayout.LayoutParams ps = new LinearLayout.LayoutParams(-1, dp(64));
        ps.topMargin = dp(18);
        root.addView(protectionSwitch, ps);
        protectionSwitch.setChecked(Prefs.isProtectionEnabled(this));
        protectionSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Prefs.setProtectionEnabled(this, isChecked);
            SessionManager.clearAll();
            refreshStatus();
        });

        addSection(root, "Apps");
        Button apps = button("Choose locked apps");
        root.addView(apps, fullButtonParams());
        apps.setOnClickListener(v -> startActivity(new Intent(this, AppPickerActivity.class)));

        addSection(root, "Unlock");
        Button method = button("Lock method");
        root.addView(method, fullButtonParams());
        method.setOnClickListener(v -> chooseMethod());

        Switch biometric = new Switch(this);
        biometric.setText("Fingerprint");
        biometric.setTextColor(Color.WHITE);
        biometric.setChecked(Prefs.isBiometricEnabled(this) && canUseBiometric());
        biometric.setEnabled(canUseBiometric());
        root.addView(biometric, new LinearLayout.LayoutParams(-1, dp(56)));
        biometric.setOnCheckedChangeListener((buttonView, isChecked) -> Prefs.setBiometricEnabled(this, isChecked));

        Switch lines = new Switch(this);
        lines.setText("Show pattern lines");
        lines.setTextColor(Color.WHITE);
        lines.setChecked(Prefs.showPatternLines(this));
        root.addView(lines, new LinearLayout.LayoutParams(-1, dp(56)));
        lines.setOnCheckedChangeListener((buttonView, isChecked) -> Prefs.setShowPatternLines(this, isChecked));

        Switch touches = new Switch(this);
        touches.setText("Highlight touched dots");
        touches.setTextColor(Color.WHITE);
        touches.setChecked(Prefs.showPatternTouches(this));
        root.addView(touches, new LinearLayout.LayoutParams(-1, dp(56)));
        touches.setOnCheckedChangeListener((buttonView, isChecked) -> Prefs.setShowPatternTouches(this, isChecked));

        Switch haptic = new Switch(this);
        haptic.setText("Vibrate while drawing pattern");
        haptic.setTextColor(Color.WHITE);
        haptic.setChecked(Prefs.patternHaptic(this));
        root.addView(haptic, new LinearLayout.LayoutParams(-1, dp(56)));
        haptic.setOnCheckedChangeListener((buttonView, isChecked) -> Prefs.setPatternHaptic(this, isChecked));

        addSection(root, "Lock timing");
        Button auto = button("Auto lock timing");
        root.addView(auto, fullButtonParams());
        auto.setOnClickListener(v -> chooseAutoLock());

        Button temp = button("Temporary unlock");
        root.addView(temp, fullButtonParams());
        temp.setOnClickListener(v -> chooseTemporaryUnlock());

        addSection(root, "Appearance");
        Button background = button("Choose lock background");
        root.addView(background, fullButtonParams());
        background.setOnClickListener(v -> chooseBackground());

        Button resetBg = button("Use original background");
        root.addView(resetBg, fullButtonParams());
        resetBg.setOnClickListener(v -> {
            Prefs.setBackgroundUri(this, null);
            Toast.makeText(this, "Original background restored", Toast.LENGTH_SHORT).show();
        });

        Button dim = button("Background darkness");
        root.addView(dim, fullButtonParams());
        dim.setOnClickListener(v -> chooseDim());

        addSection(root, "Required Android access");
        accessText = text("", 14, Color.LTGRAY);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.bottomMargin = dp(8);
        root.addView(accessText, ap);

        Button accessibility = button("Open Accessibility settings");
        root.addView(accessibility, fullButtonParams());
        accessibility.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            catch (Exception e) { Toast.makeText(this, "Could not open Accessibility settings", Toast.LENGTH_SHORT).show(); }
        });

        Button appInfo = button("Open App info");
        root.addView(appInfo, fullButtonParams());
        appInfo.setOnClickListener(v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        });

        TextView privacy = text("No account, ads, analytics, location, camera, microphone, or internet access is used by this app.", 13, Color.GRAY);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = dp(22);
        root.addView(privacy, pp);

        setContentView(scroll);
        refreshStatus();
    }

    private void refreshStatus() {
        if (statusText == null) return;
        Set<String> locked = Prefs.getLockedApps(this);
        long temp = Prefs.getTemporaryOffUntil(this);
        String state;
        if (!Prefs.isProtectionEnabled(this)) state = "Protection OFF";
        else if (temp > System.currentTimeMillis()) state = "Protection temporarily paused";
        else state = "Protection ON";
        statusText.setText(state + "  •  " + locked.size() + " apps selected");
        if (protectionSwitch != null && protectionSwitch.isChecked() != Prefs.isProtectionEnabled(this)) {
            protectionSwitch.setChecked(Prefs.isProtectionEnabled(this));
        }
        if (accessText != null) {
            accessText.setText(isAccessibilityEnabled() ? "Accessibility service is ON" : "Accessibility service is OFF. App locking will not work until it is enabled.");
        }
    }

    private void chooseMethod() {
        String[] options = {"Pattern", "PIN"};
        new AlertDialog.Builder(this)
                .setTitle("Choose lock method")
                .setItems(options, (dialog, which) -> {
                    String method = which == 0 ? Prefs.METHOD_PATTERN : Prefs.METHOD_PIN;
                    Intent i = new Intent(this, SetupCredentialActivity.class);
                    i.putExtra(SetupCredentialActivity.EXTRA_METHOD, method);
                    startActivityForResult(i, REQ_CHANGE_CREDENTIAL);
                }).show();
    }

    private void chooseAutoLock() {
        String[] options = {"Immediately after leaving", "After 30 seconds", "After 1 minute", "After 5 minutes", "After 10 minutes"};
        long[] values = {0L, 30_000L, 60_000L, 300_000L, 600_000L};
        new AlertDialog.Builder(this)
                .setTitle("Auto lock")
                .setItems(options, (dialog, which) -> {
                    Prefs.setAutoLockDelay(this, values[which]);
                    SessionManager.clearAll();
                    Toast.makeText(this, options[which], Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void chooseTemporaryUnlock() {
        String[] options = {"10 minutes", "30 minutes", "1 hour", "Until I turn protection on again", "Cancel temporary unlock"};
        new AlertDialog.Builder(this)
                .setTitle("Temporary unlock")
                .setItems(options, (dialog, which) -> {
                    long now = System.currentTimeMillis();
                    if (which == 0) Prefs.setTemporaryOffUntil(this, now + 10 * 60_000L);
                    else if (which == 1) Prefs.setTemporaryOffUntil(this, now + 30 * 60_000L);
                    else if (which == 2) Prefs.setTemporaryOffUntil(this, now + 60 * 60_000L);
                    else if (which == 3) Prefs.setProtectionEnabled(this, false);
                    else Prefs.setTemporaryOffUntil(this, 0L);
                    SessionManager.clearAll();
                    refreshStatus();
                }).show();
    }

    private void chooseBackground() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_BACKGROUND);
    }

    private void chooseDim() {
        String[] options = {"Normal", "Slightly dark", "Darker"};
        new AlertDialog.Builder(this)
                .setTitle("Background darkness")
                .setSingleChoiceItems(options, Prefs.getBackgroundDim(this), (dialog, which) -> {
                    Prefs.setBackgroundDim(this, which);
                    dialog.dismiss();
                }).show();
    }

    private boolean canUseBiometric() {
        if (Build.VERSION.SDK_INT < 28) return false;
        PackageManager pm = getPackageManager();
        boolean feature = pm.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT);
        KeyguardManager km = getSystemService(KeyguardManager.class);
        return feature && km != null && km.isDeviceSecure();
    }

    private boolean isAccessibilityEnabled() {
        ComponentName expected = new ComponentName(this, LockAccessibilityService.class);
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            ComponentName cn = ComponentName.unflattenFromString(splitter.next());
            if (expected.equals(cn)) return true;
        }
        return false;
    }

    private void showFirstRunHelp() {
        new AlertDialog.Builder(this)
                .setTitle("One Android setting is required")
                .setMessage("Choose the apps you want to lock, then enable Lock by Isril in Accessibility settings. On some Samsung phones, you may first need to open App info and allow Restricted settings.")
                .setPositiveButton("Open Accessibility", (d, w) -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                .setNegativeButton("Later", null)
                .show();
    }

    private void addSection(LinearLayout root, String label) {
        TextView t = text(label, 15, Color.GRAY);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(22);
        p.bottomMargin = dp(5);
        root.addView(t, p);
    }

    private LinearLayout.LayoutParams fullButtonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54));
        p.bottomMargin = dp(7);
        return p;
    }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setPadding(dp(16), 0, dp(16), 0);
        return b;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
