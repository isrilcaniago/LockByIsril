package com.isril.lockbyisril;

import android.content.Context;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SessionManager {
    private static final Map<String, Long> unlockedAt = new ConcurrentHashMap<>();
    private static final Map<String, Long> exitedAt = new ConcurrentHashMap<>();

    private SessionManager() {}

    public static void markUnlocked(String pkg) {
        if (pkg != null) unlockedAt.put(pkg, System.currentTimeMillis());
    }

    public static void markExited(String pkg) {
        if (pkg != null) exitedAt.put(pkg, System.currentTimeMillis());
    }

    public static boolean shouldLock(Context c, String pkg) {
        Long unlocked = unlockedAt.get(pkg);
        if (unlocked == null) return true;
        Long exited = exitedAt.get(pkg);
        if (exited == null || unlocked >= exited) return false;
        long delay = Prefs.getAutoLockDelay(c);
        if (delay <= 0L) return true;
        return System.currentTimeMillis() - exited >= delay;
    }

    public static void clearAll() {
        unlockedAt.clear();
        exitedAt.clear();
    }
}
