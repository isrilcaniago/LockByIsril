# Lock by Isril

Private Android app lock made for Android 15.

## Main features

* Master Protection switch
* Choose apps to lock
* Pattern or PIN
* Fingerprint unlock using Android BiometricPrompt
* Invisible pattern line by default
* Optional touched dot highlight and haptic feedback
* Original Isril portrait as lock background
* Custom background picker
* Auto lock immediately, after 30 seconds, 1 minute, 5 minutes, or 10 minutes
* Lock sessions are cleared when the screen turns off
* Temporary unlock for 10 minutes, 30 minutes, or 1 hour
* Settings screen itself requires authentication
* Five failed attempts trigger a 30 second lockout
* Credential verification uses a non exportable HMAC key stored in Android Keystore
* No account, ads, analytics, location, camera, microphone, or network permission

## First install

1. Install the APK.
2. Open Lock by Isril.
3. Create your pattern.
4. Select the apps you want to protect.
5. Open Accessibility settings from inside the app and enable Lock by Isril.
6. On Samsung Android 13 or newer, if Android blocks the Accessibility toggle for a sideloaded APK, open App info for Lock by Isril, open the menu in the top right, choose Allow restricted settings, then return to Accessibility and enable it.

Android requires the Accessibility service to be enabled manually. An ordinary Android app cannot grant this permission to itself.

## Build

The project has no third party Android libraries. Open it in a current Android Studio and build the debug APK, or use the included GitHub Actions workflow. The workflow publishes `app-debug.apk` as an artifact.

Package name is `com.isril.lockbyisril`.
